Jon Flees
2291507
flees@chapman.edu
CPSC350: Data Structures and Algorithms
Assignment 1

Included:

Input files: 2 .txt files (myDNA.txt & myDNA2.txt) for the code to read from file.
Header file: DNA.h
Main file: A1.cpp
Output file: jonflees.out

Used a few resources from online which are cited in my code as comments with description.

Could not figure out how to do some equations without arrays. Specifically, calculating the probabilities of the bigrams, and returning totalLength of each string individually so that I could use that in my calculation for sDev.